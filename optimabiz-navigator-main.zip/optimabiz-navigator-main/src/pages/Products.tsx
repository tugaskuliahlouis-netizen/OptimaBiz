import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { GlassCard } from "@/components/ui/GlassCard";
import { GlowButton } from "@/components/ui/GlowButton";
import { GlowInput } from "@/components/ui/GlowInput";
import { 
  Plus, 
  Package, 
  TrendingUp,
  Edit2,
  Trash2,
  X,
  Calculator,
  ImagePlus,
  Image as ImageIcon
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  category: string;
  buyPrice: number;
  sellPrice: number;
  stock: number;
  margin: number;
  image?: string;
}

const categories = ["Kuliner", "Fashion", "Kerajinan", "Elektronik", "Kecantikan", "Lainnya"];

export default function Products() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Form state
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Kuliner");
  const [buyPrice, setBuyPrice] = useState("");
  const [sellPrice, setSellPrice] = useState("");
  const [stock, setStock] = useState("");
  const [productImage, setProductImage] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Calculate margin in real-time
  const calculateMargin = () => {
    const buy = parseFloat(buyPrice) || 0;
    const sell = parseFloat(sellPrice) || 0;
    if (buy === 0 || sell === 0) return 0;
    return Math.round(((sell - buy) / sell) * 100);
  };

  const margin = calculateMargin();

  useEffect(() => {
    const session = localStorage.getItem("optimabiz_session");
    if (!session) {
      navigate("/");
      return;
    }

    // Load products
    const savedProducts = localStorage.getItem("optimabiz_products");
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    }
  }, [navigate]);

  const resetForm = () => {
    setName("");
    setCategory("Kuliner");
    setBuyPrice("");
    setSellPrice("");
    setStock("");
    setProductImage("");
    setEditingProduct(null);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Ukuran file maksimal 2MB");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProductImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const productData: Product = {
      id: editingProduct?.id || Date.now().toString(),
      name,
      category,
      buyPrice: parseFloat(buyPrice),
      sellPrice: parseFloat(sellPrice),
      stock: parseInt(stock),
      margin: calculateMargin(),
      image: productImage || editingProduct?.image,
    };

    let updatedProducts: Product[];
    if (editingProduct) {
      updatedProducts = products.map(p => p.id === editingProduct.id ? productData : p);
    } else {
      updatedProducts = [...products, productData];
    }

    setProducts(updatedProducts);
    localStorage.setItem("optimabiz_products", JSON.stringify(updatedProducts));
    setShowModal(false);
    resetForm();
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setName(product.name);
    setCategory(product.category);
    setBuyPrice(product.buyPrice.toString());
    setSellPrice(product.sellPrice.toString());
    setStock(product.stock.toString());
    setProductImage(product.image || "");
    setShowModal(true);
  };

  const handleDelete = (id: string) => {
    const updatedProducts = products.filter(p => p.id !== id);
    setProducts(updatedProducts);
    localStorage.setItem("optimabiz_products", JSON.stringify(updatedProducts));
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(num);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
              Manajemen <span className="text-gradient">Produk</span>
            </h1>
            <p className="text-muted-foreground mt-1">
              Kelola inventaris dan hitung margin produk Anda
            </p>
          </div>
          <GlowButton 
            onClick={() => { resetForm(); setShowModal(true); }} 
            className="flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Tambah Produk
          </GlowButton>
        </div>

        {/* Products Grid */}
        {products.length === 0 ? (
          <GlassCard className="text-center py-16">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-primary/20 flex items-center justify-center mb-6">
              <Package className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-xl font-display font-semibold text-foreground mb-2">
              Belum Ada Produk
            </h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Mulai tambahkan produk Anda untuk mendapatkan analisis dan strategi bisnis
            </p>
            <GlowButton onClick={() => setShowModal(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Tambah Produk Pertama
            </GlowButton>
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product, index) => (
              <GlassCard 
                key={product.id}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` } as React.CSSProperties}
              >
                <div className="flex items-start justify-between mb-4">
                  {product.image ? (
                    <div className="w-12 h-12 rounded-xl overflow-hidden">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-gradient-primary/20 flex items-center justify-center">
                      <span className="text-xl font-bold text-primary">{product.name[0]}</span>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleEdit(product)}
                      className="p-2 rounded-lg hover:bg-secondary transition-colors"
                    >
                      <Edit2 className="w-4 h-4 text-muted-foreground" />
                    </button>
                    <button 
                      onClick={() => handleDelete(product.id)}
                      className="p-2 rounded-lg hover:bg-destructive/20 transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                </div>

                <h3 className="font-semibold text-lg text-foreground mb-1">{product.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{product.category}</p>

                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Harga Beli</span>
                    <span className="text-foreground">{formatCurrency(product.buyPrice)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Harga Jual</span>
                    <span className="text-foreground">{formatCurrency(product.sellPrice)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Stok</span>
                    <span className="text-foreground">{product.stock} unit</span>
                  </div>
                  <div className="pt-3 border-t border-border flex justify-between items-center">
                    <span className="text-muted-foreground flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" />
                      Margin
                    </span>
                    <span className={`text-lg font-bold ${
                      product.margin >= 30 ? "text-success" : 
                      product.margin >= 15 ? "text-warning" : "text-destructive"
                    }`}>
                      {product.margin}%
                    </span>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        )}

        {/* Add/Edit Modal */}
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div 
              className="absolute inset-0 bg-background/80 backdrop-blur-sm"
              onClick={() => { setShowModal(false); resetForm(); }}
            />
            <GlassCard className="relative w-full max-w-lg animate-fade-in" glow>
              <button 
                onClick={() => { setShowModal(false); resetForm(); }}
                className="absolute top-4 right-4 p-2 rounded-lg hover:bg-secondary transition-colors"
              >
                <X className="w-5 h-5 text-muted-foreground" />
              </button>

              <h2 className="text-xl font-display font-bold text-foreground mb-6">
                {editingProduct ? "Edit Produk" : "Tambah Produk Baru"}
              </h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Image Upload */}
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-muted-foreground">
                    Foto Produk
                  </label>
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="relative w-full h-32 rounded-lg border-2 border-dashed border-border hover:border-primary/50 transition-colors cursor-pointer bg-input/50 flex items-center justify-center overflow-hidden group"
                  >
                    {productImage ? (
                      <>
                        <img 
                          src={productImage} 
                          alt="Preview" 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="text-sm text-foreground">Klik untuk ganti foto</span>
                        </div>
                      </>
                    ) : (
                      <div className="text-center">
                        <ImagePlus className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <span className="text-sm text-muted-foreground">Klik untuk upload foto</span>
                        <p className="text-xs text-muted-foreground mt-1">Max 2MB</p>
                      </div>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>

                <GlowInput
                  label="Nama Produk"
                  placeholder="Contoh: Kopi Arabica Premium"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-muted-foreground">
                    Kategori
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground focus:outline-none focus:border-primary transition-colors"
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <GlowInput
                    label="Harga Beli (Rp)"
                    type="number"
                    placeholder="50000"
                    value={buyPrice}
                    onChange={(e) => setBuyPrice(e.target.value)}
                    required
                  />
                  <GlowInput
                    label="Harga Jual (Rp)"
                    type="number"
                    placeholder="75000"
                    value={sellPrice}
                    onChange={(e) => setSellPrice(e.target.value)}
                    required
                  />
                </div>

                <GlowInput
                  label="Stok"
                  type="number"
                  placeholder="100"
                  value={stock}
                  onChange={(e) => setStock(e.target.value)}
                  required
                />

                {/* Margin Calculator */}
                <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Calculator className="w-4 h-4" />
                      <span className="text-sm">Margin Keuntungan</span>
                    </div>
                    <span className={`text-2xl font-display font-bold ${
                      margin >= 30 ? "text-success" : 
                      margin >= 15 ? "text-warning" : 
                      margin > 0 ? "text-destructive" : "text-muted-foreground"
                    }`}>
                      {margin}%
                    </span>
                  </div>
                  {margin > 0 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Profit per unit: {formatCurrency((parseFloat(sellPrice) || 0) - (parseFloat(buyPrice) || 0))}
                    </p>
                  )}
                </div>

                <div className="flex gap-3 pt-4">
                  <GlowButton 
                    type="button" 
                    variant="secondary" 
                    className="flex-1"
                    onClick={() => { setShowModal(false); resetForm(); }}
                  >
                    Batal
                  </GlowButton>
                  <GlowButton type="submit" className="flex-1">
                    {editingProduct ? "Simpan Perubahan" : "Tambah Produk"}
                  </GlowButton>
                </div>
              </form>
            </GlassCard>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
