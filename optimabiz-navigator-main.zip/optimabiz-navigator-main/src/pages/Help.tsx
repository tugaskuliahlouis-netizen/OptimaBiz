import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { GlassCard } from "@/components/ui/GlassCard";
import { 
  HelpCircle, 
  BookOpen, 
  MessageCircle, 
  Video,
  ExternalLink
} from "lucide-react";

const helpItems = [
  {
    icon: BookOpen,
    title: "Panduan Memulai",
    description: "Pelajari cara menggunakan OptimaBiz dari awal",
    color: "primary"
  },
  {
    icon: Video,
    title: "Video Tutorial",
    description: "Tonton tutorial langkah demi langkah",
    color: "success"
  },
  {
    icon: MessageCircle,
    title: "Hubungi Support",
    description: "Tim kami siap membantu Anda",
    color: "accent"
  },
  {
    icon: HelpCircle,
    title: "FAQ",
    description: "Temukan jawaban untuk pertanyaan umum",
    color: "warning"
  }
];

export default function Help() {
  const navigate = useNavigate();

  useEffect(() => {
    const session = localStorage.getItem("optimabiz_session");
    if (!session) {
      navigate("/");
    }
  }, [navigate]);

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
            Pusat <span className="text-gradient">Bantuan</span>
          </h1>
          <p className="text-muted-foreground mt-2 max-w-md mx-auto">
            Temukan panduan dan dukungan untuk memaksimalkan penggunaan OptimaBiz
          </p>
        </div>

        {/* Help Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {helpItems.map((item, index) => (
            <GlassCard 
              key={item.title}
              className="cursor-pointer group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` } as React.CSSProperties}
            >
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  item.color === "primary" ? "bg-primary/20" :
                  item.color === "success" ? "bg-success/20" :
                  item.color === "accent" ? "bg-accent/20" :
                  "bg-warning/20"
                }`}>
                  <item.icon className={`w-6 h-6 ${
                    item.color === "primary" ? "text-primary" :
                    item.color === "success" ? "text-success" :
                    item.color === "accent" ? "text-accent" :
                    "text-warning"
                  }`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {item.title}
                    </h3>
                    <ExternalLink className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {item.description}
                  </p>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>

        {/* Quick Tips */}
        <GlassCard glow>
          <h3 className="font-display font-semibold text-lg text-foreground mb-4">
            💡 Tips Cepat
          </h3>
          <ul className="space-y-3">
            {[
              "Mulai dengan menambahkan 3-5 produk unggulan Anda",
              "Gunakan fitur Strategi AI untuk mendapatkan rekomendasi platform",
              "Ikuti timeline mingguan untuk hasil optimal",
              "Pantau margin keuntungan secara berkala"
            ].map((tip, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
                  {index + 1}
                </span>
                <span className="text-muted-foreground">{tip}</span>
              </li>
            ))}
          </ul>
        </GlassCard>
      </div>
    </DashboardLayout>
  );
}
