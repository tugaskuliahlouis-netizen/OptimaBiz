import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { GlassCard } from "@/components/ui/GlassCard";
import { GlowButton } from "@/components/ui/GlowButton";
import { 
  Package, 
  TrendingUp, 
  DollarSign, 
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Zap,
  BarChart3,
  Clock
} from "lucide-react";

const stats = [
  { 
    label: "Total Produk", 
    value: "12", 
    change: "+2", 
    isPositive: true,
    icon: Package,
    color: "primary"
  },
  { 
    label: "Total Penjualan", 
    value: "Rp 15.8M", 
    change: "+18%", 
    isPositive: true,
    icon: DollarSign,
    color: "success"
  },
  { 
    label: "Margin Rata-rata", 
    value: "32%", 
    change: "-2%", 
    isPositive: false,
    icon: TrendingUp,
    color: "warning"
  },
  { 
    label: "Target Tercapai", 
    value: "78%", 
    change: "+12%", 
    isPositive: true,
    icon: Target,
    color: "accent"
  },
];

const recentProducts = [
  { name: "Kopi Arabica Premium", category: "Kuliner", margin: "45%", status: "active" },
  { name: "Batik Tulis Madura", category: "Fashion", margin: "38%", status: "active" },
  { name: "Keripik Tempe", category: "Kuliner", margin: "52%", status: "pending" },
];

const weeklyTasks = [
  { task: "Setup Toko di TikTok Shop", status: "done", week: 1 },
  { task: "Upload 5 Produk Best Seller", status: "in-progress", week: 1 },
  { task: "Buat Konten Video Produk", status: "pending", week: 2 },
  { task: "Launch Campaign Pertama", status: "pending", week: 2 },
];

export default function Dashboard() {
  const [user, setUser] = useState<any>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const session = localStorage.getItem("optimabiz_session");
    if (!session) {
      navigate("/");
      return;
    }
    setUser(JSON.parse(session));
  }, [navigate]);

  if (!user) return null;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Welcome Section */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
              Selamat Datang, <span className="text-gradient">{user.name}</span>
            </h1>
            <p className="text-muted-foreground mt-1">
              Berikut ringkasan performa bisnis Anda hari ini
            </p>
          </div>
          <GlowButton onClick={() => navigate("/products")} className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Tambah Produk
          </GlowButton>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {stats.map((stat, index) => (
            <GlassCard 
              key={stat.label} 
              className="animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` } as React.CSSProperties}
            >
              <div className="flex items-start justify-between">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  stat.color === "primary" ? "bg-primary/20" :
                  stat.color === "success" ? "bg-success/20" :
                  stat.color === "warning" ? "bg-warning/20" :
                  "bg-accent/20"
                }`}>
                  <stat.icon className={`w-6 h-6 ${
                    stat.color === "primary" ? "text-primary" :
                    stat.color === "success" ? "text-success" :
                    stat.color === "warning" ? "text-warning" :
                    "text-accent"
                  }`} />
                </div>
                <div className={`flex items-center gap-1 text-sm font-medium ${
                  stat.isPositive ? "text-success" : "text-destructive"
                }`}>
                  {stat.isPositive ? (
                    <ArrowUpRight className="w-4 h-4" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4" />
                  )}
                  {stat.change}
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-display font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </div>
            </GlassCard>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Products */}
          <GlassCard className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                  <Package className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display font-semibold text-lg text-foreground">
                  Produk Terbaru
                </h3>
              </div>
              <button 
                onClick={() => navigate("/products")}
                className="text-sm text-primary hover:underline"
              >
                Lihat Semua
              </button>
            </div>

            <div className="space-y-4">
              {recentProducts.map((product, index) => (
                <div 
                  key={index}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 border border-border hover:border-primary/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-gradient-primary/20 flex items-center justify-center">
                      <span className="text-lg font-bold text-primary">
                        {product.name[0]}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{product.name}</p>
                      <p className="text-sm text-muted-foreground">{product.category}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="font-medium text-success">{product.margin}</p>
                      <p className="text-xs text-muted-foreground">Margin</p>
                    </div>
                    <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                      product.status === "active" 
                        ? "bg-success/20 text-success" 
                        : "bg-warning/20 text-warning"
                    }`}>
                      {product.status === "active" ? "Aktif" : "Pending"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>

          {/* Weekly Tasks */}
          <GlassCard>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                <Clock className="w-5 h-5 text-accent" />
              </div>
              <h3 className="font-display font-semibold text-lg text-foreground">
                Rencana Minggu Ini
              </h3>
            </div>

            <div className="space-y-3">
              {weeklyTasks.map((item, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30"
                >
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 ${
                    item.status === "done" 
                      ? "bg-success border-success" 
                      : item.status === "in-progress"
                      ? "border-primary animate-pulse"
                      : "border-muted-foreground"
                  }`}>
                    {item.status === "done" && (
                      <svg className="w-3 h-3 text-success-foreground" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    )}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm font-medium ${
                      item.status === "done" ? "text-muted-foreground line-through" : "text-foreground"
                    }`}>
                      {item.task}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">Minggu {item.week}</p>
                  </div>
                </div>
              ))}
            </div>

            <GlowButton 
              variant="secondary" 
              className="w-full mt-6"
              onClick={() => navigate("/strategy")}
            >
              <Zap className="w-4 h-4 mr-2" />
              Lihat Strategi Lengkap
            </GlowButton>
          </GlassCard>
        </div>

        {/* Quick Actions */}
        <GlassCard glow>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow animate-glow-pulse">
                <BarChart3 className="w-7 h-7 text-primary-foreground" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-lg text-foreground">
                  Dapatkan Strategi AI
                </h3>
                <p className="text-muted-foreground">
                  Analisis produk dan dapatkan rekomendasi platform terbaik
                </p>
              </div>
            </div>
            <GlowButton onClick={() => navigate("/strategy")} className="flex items-center gap-2">
              Mulai Analisis
              <ArrowUpRight className="w-4 h-4" />
            </GlowButton>
          </div>
        </GlassCard>
      </div>
    </DashboardLayout>
  );
}
