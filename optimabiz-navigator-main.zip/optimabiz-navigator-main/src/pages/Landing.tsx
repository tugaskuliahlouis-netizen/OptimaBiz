import { useNavigate } from "react-router-dom";
import { GlassCard } from "@/components/ui/GlassCard";
import { GlowButton } from "@/components/ui/GlowButton";
import { 
  Zap, 
  ArrowRight, 
  Sparkles, 
  BarChart3, 
  Target, 
  TrendingUp,
  CheckCircle,
  Users,
  Shield,
  Rocket
} from "lucide-react";

export default function Landing() {
  const navigate = useNavigate();

  const features = [
    {
      icon: Target,
      title: "Rekomendasi Platform AI",
      description: "Sistem cerdas yang menganalisis produk Anda dan merekomendasikan platform penjualan terbaik seperti TikTok Shop, Shopee, atau GoFood."
    },
    {
      icon: BarChart3,
      title: "Kalkulator Margin Real-Time",
      description: "Hitung profitabilitas produk secara instan. Lihat margin keuntungan dan profit per unit saat memasukkan harga."
    },
    {
      icon: TrendingUp,
      title: "Strategi Pertumbuhan Mingguan",
      description: "Dapatkan rencana aksi per minggu yang terstruktur untuk mengembangkan bisnis dari tahap setup hingga scaling."
    },
    {
      icon: Rocket,
      title: "Decision Engine",
      description: "Mesin pengambil keputusan yang mengubah data produk menjadi langkah taktis spesifik sesuai kategori bisnis Anda."
    }
  ];

  const benefits = [
    "Analisis produk otomatis",
    "Timeline strategi 4 minggu",
    "Multi-platform recommendation",
    "Kalkulator profit terintegrasi",
    "Dashboard analytics lengkap",
    "Akses kapan saja, di mana saja"
  ];

  const stats = [
    { value: "500+", label: "UMKM Terbantu" },
    { value: "95%", label: "Tingkat Kepuasan" },
    { value: "4x", label: "Rata-rata Pertumbuhan" }
  ];

  return (
    <div className="min-h-screen">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-bold text-foreground">OptimaBiz</span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate("/auth?mode=login")}
              className="text-muted-foreground hover:text-foreground transition-colors font-medium"
            >
              Masuk
            </button>
            <GlowButton onClick={() => navigate("/auth?mode=register")} size="sm">
              Mulai Gratis
            </GlowButton>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-6 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-mesh opacity-50" />
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-primary/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-accent/10 rounded-full blur-[120px]" />
        
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="text-center max-w-4xl mx-auto">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8 animate-fade-in">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-primary font-medium">Enterprise Navigator untuk UMKM</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold text-foreground mb-6 leading-tight animate-fade-in" style={{ animationDelay: "0.1s" }}>
              Transformasi Data Produk
              <br />
              <span className="text-gradient">Menjadi Aksi Nyata</span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto animate-fade-in" style={{ animationDelay: "0.2s" }}>
              Sistem navigasi strategis yang membantu UMKM menentukan platform terbaik 
              dan rencana aksi mingguan untuk pertumbuhan bisnis yang terukur.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <GlowButton onClick={() => navigate("/auth?mode=register")} size="lg" className="w-full sm:w-auto">
                Mulai Gratis Sekarang
                <ArrowRight className="w-5 h-5 ml-2" />
              </GlowButton>
              <button 
                onClick={() => navigate("/auth?mode=login")}
                className="flex items-center gap-2 px-6 py-3 text-foreground hover:text-primary transition-colors font-medium"
              >
                Sudah punya akun? Masuk
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 mt-16 max-w-lg mx-auto animate-fade-in" style={{ animationDelay: "0.4s" }}>
              {stats.map((stat, i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl font-display font-bold text-gradient">{stat.value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Hero Visual */}
          <div className="mt-20 relative animate-fade-in" style={{ animationDelay: "0.5s" }}>
            <GlassCard className="p-8 max-w-4xl mx-auto" glow>
              <div className="aspect-video rounded-lg bg-gradient-to-br from-secondary to-background flex items-center justify-center relative overflow-hidden">
                {/* Mock Dashboard Preview */}
                <div className="absolute inset-4 rounded-lg border border-border/50 bg-card/50 p-4">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                      <BarChart3 className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <div className="h-3 w-24 bg-muted rounded" />
                      <div className="h-2 w-16 bg-muted/50 rounded mt-1" />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="rounded-lg bg-secondary/50 p-3">
                        <div className="h-2 w-12 bg-muted rounded mb-2" />
                        <div className="h-6 w-16 bg-primary/30 rounded" />
                      </div>
                    ))}
                  </div>
                  <div className="mt-4 h-32 rounded-lg bg-gradient-to-t from-primary/10 to-transparent" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-foreground mb-4">
              Fitur <span className="text-gradient">Unggulan</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Semua yang Anda butuhkan untuk mengembangkan bisnis UMKM dengan strategi yang terukur
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, i) => (
              <GlassCard 
                key={i} 
                className="animate-fade-in hover:border-primary/30 transition-colors"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-display font-semibold text-foreground mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-6 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-display font-bold text-foreground mb-6">
                Mengapa Memilih <span className="text-gradient">OptimaBiz?</span>
              </h2>
              <p className="text-muted-foreground mb-8">
                Kami memahami tantangan UMKM di era digital. OptimaBiz hadir sebagai partner strategis 
                yang membantu Anda mengambil keputusan bisnis berbasis data, bukan asumsi.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {benefits.map((benefit, i) => (
                  <div key={i} className="flex items-center gap-3 animate-fade-in" style={{ animationDelay: `${i * 0.05}s` }}>
                    <CheckCircle className="w-5 h-5 text-success shrink-0" />
                    <span className="text-foreground">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            <GlassCard className="p-8" glow>
              <div className="space-y-6">
                <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/50">
                  <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">Untuk Semua Skala UMKM</div>
                    <div className="text-sm text-muted-foreground">Dari pemula hingga yang sudah berkembang</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/50">
                  <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-success" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">Data Aman & Privat</div>
                    <div className="text-sm text-muted-foreground">Informasi bisnis Anda terlindungi</div>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-lg bg-secondary/50">
                  <div className="w-12 h-12 rounded-xl bg-warning/20 flex items-center justify-center">
                    <Rocket className="w-6 h-6 text-warning" />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">Hasil dalam 4 Minggu</div>
                    <div className="text-sm text-muted-foreground">Strategi terstruktur dengan timeline jelas</div>
                  </div>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <GlassCard className="text-center p-12" glow>
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-primary flex items-center justify-center shadow-glow mb-8 animate-float">
              <Zap className="w-8 h-8 text-primary-foreground" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-display font-bold text-foreground mb-4">
              Siap Mengembangkan Bisnis Anda?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
              Bergabung dengan ratusan UMKM lainnya yang sudah merasakan manfaat OptimaBiz. 
              Mulai perjalanan transformasi bisnis Anda hari ini.
            </p>
            <GlowButton onClick={() => navigate("/auth?mode=register")} size="lg">
              Daftar Gratis Sekarang
              <ArrowRight className="w-5 h-5 ml-2" />
            </GlowButton>
            <p className="text-sm text-muted-foreground mt-4">
              Tidak perlu kartu kredit • Akses penuh ke semua fitur
            </p>
          </GlassCard>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-border">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-semibold text-foreground">OptimaBiz</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2024 OptimaBiz. Enterprise Navigator untuk UMKM Indonesia.
          </p>
        </div>
      </footer>
    </div>
  );
}
