import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { GlassCard } from "@/components/ui/GlassCard";
import { GlowButton } from "@/components/ui/GlowButton";
import { GlowInput } from "@/components/ui/GlowInput";
import { 
  User, 
  Building2, 
  MapPin, 
  Target,
  Save,
  LogOut
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BrandProfile {
  brandName: string;
  ownerName: string;
  location: string;
  marketScope: "local" | "national" | "international";
  description: string;
}

export default function Settings() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [profile, setProfile] = useState<BrandProfile>({
    brandName: "",
    ownerName: "",
    location: "",
    marketScope: "local",
    description: ""
  });

  useEffect(() => {
    const session = localStorage.getItem("optimabiz_session");
    if (!session) {
      navigate("/");
      return;
    }

    const savedProfile = localStorage.getItem("optimabiz_brand_profile");
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile));
    } else {
      const user = JSON.parse(session);
      setProfile(prev => ({ ...prev, ownerName: user.name || "" }));
    }
  }, [navigate]);

  const handleSave = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    localStorage.setItem("optimabiz_brand_profile", JSON.stringify(profile));
    setIsLoading(false);
    toast({
      title: "Profil Tersimpan!",
      description: "Perubahan profil brand Anda telah disimpan."
    });
  };

  const handleLogout = () => {
    localStorage.removeItem("optimabiz_session");
    navigate("/");
  };

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
            <span className="text-gradient">Pengaturan</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Kelola profil brand dan preferensi Anda
          </p>
        </div>

        {/* Brand Profile */}
        <GlassCard>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-primary" />
            </div>
            <h3 className="font-display font-semibold text-lg text-foreground">
              Profil Brand
            </h3>
          </div>

          <div className="space-y-6">
            <GlowInput
              label="Nama Brand/Usaha"
              placeholder="Contoh: Batik Nusantara"
              value={profile.brandName}
              onChange={(e) => setProfile({ ...profile, brandName: e.target.value })}
            />

            <GlowInput
              label="Nama Pemilik"
              placeholder="Nama lengkap Anda"
              value={profile.ownerName}
              onChange={(e) => setProfile({ ...profile, ownerName: e.target.value })}
            />

            <div className="relative">
              <MapPin className="absolute left-4 top-[42px] w-5 h-5 text-muted-foreground" />
              <GlowInput
                label="Lokasi Usaha"
                placeholder="Kota, Provinsi"
                value={profile.location}
                onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                className="pl-12"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-muted-foreground">
                Target Pasar
              </label>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { value: "local", label: "Lokal", icon: "🏠" },
                  { value: "national", label: "Nasional", icon: "🇮🇩" },
                  { value: "international", label: "Internasional", icon: "🌏" }
                ].map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setProfile({ ...profile, marketScope: option.value as any })}
                    className={`p-4 rounded-lg border-2 text-center transition-all duration-300 ${
                      profile.marketScope === option.value
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary/30 hover:border-primary/50"
                    }`}
                  >
                    <span className="text-2xl mb-2 block">{option.icon}</span>
                    <span className="text-sm font-medium text-foreground">{option.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-muted-foreground">
                Deskripsi Usaha
              </label>
              <textarea
                placeholder="Ceritakan tentang brand Anda..."
                value={profile.description}
                onChange={(e) => setProfile({ ...profile, description: e.target.value })}
                rows={4}
                className="w-full px-4 py-3 rounded-lg bg-input border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none"
              />
            </div>

            <GlowButton 
              onClick={handleSave}
              className="w-full flex items-center justify-center gap-2"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Simpan Perubahan
                </>
              )}
            </GlowButton>
          </div>
        </GlassCard>

        {/* Account Actions */}
        <GlassCard className="border-destructive/30">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-destructive/20 flex items-center justify-center">
              <User className="w-5 h-5 text-destructive" />
            </div>
            <h3 className="font-display font-semibold text-lg text-foreground">
              Akun
            </h3>
          </div>

          <p className="text-muted-foreground text-sm mb-4">
            Keluar dari akun Anda. Data akan tetap tersimpan di browser.
          </p>

          <GlowButton 
            variant="secondary"
            onClick={handleLogout}
            className="border-destructive text-destructive hover:bg-destructive/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Keluar
          </GlowButton>
        </GlassCard>
      </div>
    </DashboardLayout>
  );
}
