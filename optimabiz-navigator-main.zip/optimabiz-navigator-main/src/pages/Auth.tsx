import { useState, useEffect } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { GlassCard } from "@/components/ui/GlassCard";
import { GlowButton } from "@/components/ui/GlowButton";
import { GlowInput } from "@/components/ui/GlowInput";
import { Zap, Mail, Lock, User, ArrowRight, Sparkles, ChevronLeft } from "lucide-react";

export default function Auth() {
  const [searchParams] = useSearchParams();
  const initialMode = searchParams.get("mode") === "login";
  
  const [isLogin, setIsLogin] = useState(initialMode);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  // Update mode when URL changes
  useEffect(() => {
    const mode = searchParams.get("mode");
    setIsLogin(mode === "login");
  }, [searchParams]);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate auth delay
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Simple localStorage auth (demo)
    if (isLogin) {
      const users = JSON.parse(localStorage.getItem("optimabiz_users") || "[]");
      const user = users.find((u: any) => u.email === email && u.password === password);
      
      // Demo account check
      if (email === "user@demo.com" && password === "demo123") {
        localStorage.setItem("optimabiz_session", JSON.stringify({ email, name: "Demo User" }));
        navigate("/dashboard");
      } else if (user) {
        localStorage.setItem("optimabiz_session", JSON.stringify({ email: user.email, name: user.name }));
        navigate("/dashboard");
      } else {
        alert("Email atau password salah. Coba: user@demo.com / demo123");
      }
    } else {
      // Register
      const users = JSON.parse(localStorage.getItem("optimabiz_users") || "[]");
      users.push({ email, password, name });
      localStorage.setItem("optimabiz_users", JSON.stringify(users));
      localStorage.setItem("optimabiz_session", JSON.stringify({ email, name }));
      navigate("/dashboard");
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left Panel - Branding */}
      <div className="lg:w-1/2 p-8 lg:p-16 flex flex-col justify-center relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-mesh opacity-50" />
        <div className="absolute top-1/4 -left-32 w-64 h-64 bg-primary/20 rounded-full blur-[100px]" />
        <div className="absolute bottom-1/4 -right-32 w-64 h-64 bg-accent/10 rounded-full blur-[100px]" />
        
        <div className="relative z-10">
          {/* Back to Landing */}
          <Link 
            to="/" 
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
          >
            <ChevronLeft className="w-4 h-4" />
            Kembali ke Beranda
          </Link>

          {/* Logo */}
          <div className="flex items-center gap-4 mb-12">
            <div className="w-14 h-14 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-glow animate-float">
              <Zap className="w-7 h-7 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-display text-3xl font-bold text-foreground">OptimaBiz</h1>
              <p className="text-muted-foreground">Enterprise Navigator</p>
            </div>
          </div>

          {/* Hero Text */}
          <h2 className="text-4xl lg:text-5xl font-display font-bold text-foreground mb-6 leading-tight">
            Transformasi Data
            <br />
            <span className="text-gradient">Menjadi Aksi</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-md">
            Sistem navigasi strategis yang membantu UMKM menentukan platform terbaik 
            dan rencana aksi mingguan untuk pertumbuhan bisnis.
          </p>

          {/* Features */}
          <div className="space-y-4">
            {[
              "Rekomendasi platform berbasis AI",
              "Kalkulator margin real-time",
              "Strategi pertumbuhan mingguan"
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-3 animate-fade-in" style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center">
                  <Sparkles className="w-3 h-3 text-primary" />
                </div>
                <span className="text-foreground">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel - Auth Form */}
      <div className="lg:w-1/2 p-8 lg:p-16 flex items-center justify-center bg-card/30">
        <div className="w-full max-w-md">
          <GlassCard className="p-8" glow>
            {/* Tab Switcher */}
            <div className="flex gap-2 p-1 bg-secondary rounded-lg mb-8">
              <button
                onClick={() => setIsLogin(true)}
                className={`flex-1 py-2 px-4 rounded-md font-medium transition-all duration-300 ${
                  isLogin 
                    ? "bg-gradient-primary text-primary-foreground shadow-glow" 
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Masuk
              </button>
              <button
                onClick={() => setIsLogin(false)}
                className={`flex-1 py-2 px-4 rounded-md font-medium transition-all duration-300 ${
                  !isLogin 
                    ? "bg-gradient-primary text-primary-foreground shadow-glow" 
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                Daftar
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-6">
              {!isLogin && (
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <GlowInput
                    type="text"
                    placeholder="Nama Lengkap"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="pl-12"
                    required={!isLogin}
                  />
                </div>
              )}

              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <GlowInput
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-12"
                  required
                />
              </div>

              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <GlowInput
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-12"
                  required
                />
              </div>

              {isLogin && (
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded border-border bg-input accent-primary"
                    />
                    <span className="text-sm text-muted-foreground">Ingat Saya</span>
                  </label>
                  <button type="button" className="text-sm text-primary hover:underline">
                    Lupa Password?
                  </button>
                </div>
              )}

              <GlowButton
                type="submit"
                className="w-full flex items-center justify-center gap-2"
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                ) : (
                  <>
                    {isLogin ? "Masuk" : "Daftar Sekarang"}
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </GlowButton>
            </form>

            {/* Demo Account Info */}
            <div className="mt-6 p-4 rounded-lg bg-secondary/50 border border-border">
              <p className="text-sm text-muted-foreground text-center">
                <span className="text-primary font-medium">Demo:</span>{" "}
                user@demo.com / demo123
              </p>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
}
