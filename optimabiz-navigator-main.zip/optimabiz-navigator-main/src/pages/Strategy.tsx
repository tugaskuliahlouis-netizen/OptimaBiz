import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { GlassCard } from "@/components/ui/GlassCard";
import { GlowButton } from "@/components/ui/GlowButton";
import { 
  Zap, 
  TrendingUp, 
  Target,
  Calendar,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  AlertTriangle,
  RefreshCw
} from "lucide-react";

interface Product {
  id: string;
  name: string;
  category: string;
  margin: number;
}

const platformRecommendations: Record<string, { platforms: string[]; reason: string }> = {
  Kuliner: {
    platforms: ["TikTok Shop", "GoFood", "GrabFood", "Shopee"],
    reason: "Produk kuliner sangat cocok dengan konten visual di TikTok dan food delivery apps"
  },
  Fashion: {
    platforms: ["Shopee", "Tokopedia", "Instagram Shop", "TikTok Shop"],
    reason: "Fashion membutuhkan visual yang kuat dan jangkauan marketplace yang luas"
  },
  Kerajinan: {
    platforms: ["Etsy", "Tokopedia", "Instagram", "Shopee"],
    reason: "Kerajinan unik cocok untuk platform dengan audience yang menghargai handmade"
  },
  Elektronik: {
    platforms: ["Tokopedia", "Shopee", "Lazada", "Bukalapak"],
    reason: "Elektronik memerlukan kepercayaan tinggi dari marketplace besar"
  },
  Kecantikan: {
    platforms: ["Sociolla", "Shopee", "TikTok Shop", "Instagram"],
    reason: "Produk kecantikan sangat efektif dengan review dan tutorial video"
  },
  Lainnya: {
    platforms: ["Shopee", "Tokopedia", "Instagram", "Facebook"],
    reason: "Strategi multi-platform untuk menjangkau berbagai segmen pasar"
  }
};

const weeklyTimeline = [
  {
    week: 1,
    title: "Setup & Foundation",
    tasks: [
      "Buat akun di platform yang direkomendasikan",
      "Upload 5-10 produk unggulan dengan foto berkualitas",
      "Tulis deskripsi produk yang SEO-friendly",
      "Setup metode pembayaran dan pengiriman"
    ]
  },
  {
    week: 2,
    title: "Content & Engagement",
    tasks: [
      "Buat 3 konten video produk untuk TikTok/Reels",
      "Posting rutin di social media (2x sehari)",
      "Respond semua pertanyaan customer dalam 1 jam",
      "Collect testimoni dari customer pertama"
    ]
  },
  {
    week: 3,
    title: "Growth & Promotion",
    tasks: [
      "Launch promo diskon 10-15% untuk new customers",
      "Kolaborasi dengan 2-3 micro-influencer lokal",
      "Analisis performa dan adjust strategi",
      "Scale up stok untuk produk best-seller"
    ]
  },
  {
    week: 4,
    title: "Scaling & Optimization",
    tasks: [
      "Expand ke platform tambahan",
      "Setup iklan berbayar dengan budget kecil",
      "Optimize listing berdasarkan data penjualan",
      "Plan untuk bulan depan berdasarkan insights"
    ]
  }
];

export default function Strategy() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showStrategy, setShowStrategy] = useState(false);
  const [displayedText, setDisplayedText] = useState("");

  useEffect(() => {
    const session = localStorage.getItem("optimabiz_session");
    if (!session) {
      navigate("/");
      return;
    }

    const savedProducts = localStorage.getItem("optimabiz_products");
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    }
  }, [navigate]);

  const analyzeProduct = async () => {
    if (!selectedProduct) return;
    
    setIsAnalyzing(true);
    setShowStrategy(false);
    setDisplayedText("");

    // Simulate AI thinking
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsAnalyzing(false);
    setShowStrategy(true);

    // Typewriter effect for strategy text
    const strategyText = `Berdasarkan analisis produk "${selectedProduct.name}" dalam kategori ${selectedProduct.category} dengan margin ${selectedProduct.margin}%, berikut strategi yang direkomendasikan untuk mengoptimalkan penjualan Anda.`;
    
    let i = 0;
    const typeInterval = setInterval(() => {
      if (i < strategyText.length) {
        setDisplayedText(strategyText.slice(0, i + 1));
        i++;
      } else {
        clearInterval(typeInterval);
      }
    }, 30);
  };

  const recommendation = selectedProduct 
    ? platformRecommendations[selectedProduct.category] 
    : null;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl lg:text-3xl font-display font-bold text-foreground">
            Strategi <span className="text-gradient">AI Engine</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Dapatkan rekomendasi platform dan rencana aksi berdasarkan produk Anda
          </p>
        </div>

        {/* Product Selection */}
        <GlassCard>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
              <Target className="w-5 h-5 text-primary" />
            </div>
            <h3 className="font-display font-semibold text-lg text-foreground">
              Pilih Produk untuk Dianalisis
            </h3>
          </div>

          {products.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">
                Belum ada produk. Tambahkan produk terlebih dahulu.
              </p>
              <GlowButton onClick={() => navigate("/products")}>
                Tambah Produk
              </GlowButton>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map((product) => (
                <button
                  key={product.id}
                  onClick={() => { setSelectedProduct(product); setShowStrategy(false); }}
                  className={`p-4 rounded-lg border-2 text-left transition-all duration-300 ${
                    selectedProduct?.id === product.id
                      ? "border-primary bg-primary/10 shadow-glow"
                      : "border-border bg-secondary/30 hover:border-primary/50"
                  }`}
                >
                  <p className="font-semibold text-foreground">{product.name}</p>
                  <p className="text-sm text-muted-foreground">{product.category}</p>
                  <p className="text-sm text-success mt-2">Margin: {product.margin}%</p>
                </button>
              ))}
            </div>
          )}

          {selectedProduct && (
            <GlowButton 
              onClick={analyzeProduct}
              className="mt-6 flex items-center gap-2"
              disabled={isAnalyzing}
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Menganalisis...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Generate Strategi
                </>
              )}
            </GlowButton>
          )}
        </GlassCard>

        {/* Thinking Animation */}
        {isAnalyzing && (
          <GlassCard className="thinking-glow">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center animate-pulse">
                <Sparkles className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <p className="font-semibold text-foreground">AI sedang menganalisis...</p>
                <p className="text-sm text-muted-foreground">
                  Memproses data produk dan menemukan strategi terbaik
                </p>
              </div>
            </div>
            <div className="mt-4 h-2 rounded-full bg-secondary overflow-hidden">
              <div className="h-full bg-gradient-primary animate-[progress-shine_1.5s_ease-in-out_infinite] w-full" />
            </div>
          </GlassCard>
        )}

        {/* Strategy Output */}
        {showStrategy && recommendation && (
          <div className="space-y-6 animate-fade-in">
            {/* AI Analysis */}
            <GlassCard glow>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center shrink-0">
                  <Zap className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="font-display font-semibold text-lg text-foreground mb-2">
                    Analisis AI
                  </h3>
                  <p className="text-foreground leading-relaxed">
                    {displayedText}
                    <span className="inline-block w-0.5 h-5 bg-primary ml-1 animate-pulse" />
                  </p>
                </div>
              </div>
            </GlassCard>

            {/* Platform Recommendations */}
            <GlassCard>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-success/20 flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-success" />
                </div>
                <h3 className="font-display font-semibold text-lg text-foreground">
                  Platform yang Direkomendasikan
                </h3>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                {recommendation.platforms.map((platform, index) => (
                  <div 
                    key={platform}
                    className="p-4 rounded-lg bg-secondary/50 border border-border text-center animate-fade-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <p className="font-semibold text-foreground">{platform}</p>
                    <p className="text-xs text-primary mt-1">#{index + 1} Prioritas</p>
                  </div>
                ))}
              </div>

              <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
                <p className="text-sm text-foreground">
                  <span className="font-semibold">Alasan: </span>
                  {recommendation.reason}
                </p>
              </div>
            </GlassCard>

            {/* Weekly Timeline */}
            <GlassCard>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-accent" />
                </div>
                <h3 className="font-display font-semibold text-lg text-foreground">
                  Timeline Aksi 4 Minggu
                </h3>
              </div>

              <div className="space-y-6">
                {weeklyTimeline.map((week, weekIndex) => (
                  <div 
                    key={week.week}
                    className="animate-fade-in"
                    style={{ animationDelay: `${weekIndex * 0.15}s` }}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center text-sm font-bold text-primary-foreground">
                        {week.week}
                      </div>
                      <div>
                        <p className="font-semibold text-foreground">{week.title}</p>
                        <p className="text-xs text-muted-foreground">Minggu {week.week}</p>
                      </div>
                    </div>
                    <div className="ml-11 space-y-2">
                      {week.tasks.map((task, taskIndex) => (
                        <div key={taskIndex} className="flex items-start gap-2">
                          <CheckCircle2 className="w-4 h-4 text-success shrink-0 mt-0.5" />
                          <p className="text-sm text-muted-foreground">{task}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* Emergency Button */}
            <GlassCard className="border-warning/30 bg-warning/5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-warning/20 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-warning" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-lg text-foreground">
                      Penjualan Stagnan?
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Dapatkan 5 langkah audit kilat untuk mengatasi masalah
                    </p>
                  </div>
                </div>
                <GlowButton variant="secondary" className="border-warning text-warning hover:bg-warning/10">
                  Emergency Audit
                  <ArrowRight className="w-4 h-4 ml-2" />
                </GlowButton>
              </div>
            </GlassCard>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
