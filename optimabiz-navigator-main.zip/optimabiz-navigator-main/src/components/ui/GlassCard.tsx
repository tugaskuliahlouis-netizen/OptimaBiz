import { cn } from "@/lib/utils";
import { ReactNode, CSSProperties } from "react";

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  glow?: boolean;
  hover?: boolean;
  style?: CSSProperties;
}

export function GlassCard({ children, className, glow = false, hover = true, style }: GlassCardProps) {
  return (
    <div
      className={cn(
        "glass-card p-6",
        hover && "stat-card",
        glow && "glow-border",
        className
      )}
      style={style}
    >
      {children}
    </div>
  );
}
