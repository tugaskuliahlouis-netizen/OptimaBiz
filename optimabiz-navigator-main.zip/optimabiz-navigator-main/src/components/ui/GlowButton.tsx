import { cn } from "@/lib/utils";
import { ButtonHTMLAttributes, forwardRef } from "react";

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
}

export const GlowButton = forwardRef<HTMLButtonElement, GlowButtonProps>(
  ({ className, variant = "primary", size = "md", children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "relative font-medium transition-all duration-300 rounded-lg disabled:opacity-50 disabled:pointer-events-none",
          // Size variants
          size === "sm" && "px-4 py-2 text-sm",
          size === "md" && "px-6 py-3 text-base",
          size === "lg" && "px-8 py-4 text-lg",
          // Style variants
          variant === "primary" && [
            "bg-gradient-primary text-primary-foreground font-semibold",
            "shadow-glow hover:shadow-float",
            "hover:-translate-y-0.5 hover:scale-[1.02]",
            "active:translate-y-0 active:scale-[0.98]",
          ],
          variant === "secondary" && [
            "bg-secondary text-secondary-foreground",
            "border border-border",
            "hover:bg-secondary/80 hover:border-primary/50",
            "hover:-translate-y-0.5",
            "active:translate-y-0",
          ],
          variant === "ghost" && [
            "bg-transparent text-foreground",
            "hover:bg-secondary hover:text-primary",
          ],
          className
        )}
        {...props}
      >
        {children}
      </button>
    );
  }
);

GlowButton.displayName = "GlowButton";
